function openLogin() {
  document.getElementById("loginModal").classList.add("active");
  document.getElementById("registerModal").classList.remove("active");
}

function openRegister() {
  document.getElementById("registerModal").classList.add("active");
  document.getElementById("loginModal").classList.remove("active");
}

function closeModal() {
  document.getElementById("loginModal").classList.remove("active");
  document.getElementById("registerModal").classList.remove("active");
}
function toggleMenu() {
  document.getElementById("navMenu").classList.toggle("active");
}